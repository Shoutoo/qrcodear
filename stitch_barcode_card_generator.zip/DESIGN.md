---
name: Wildwise
colors:
  surface: '#fcf9f3'
  surface-dim: '#dcdad4'
  surface-bright: '#fcf9f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ed'
  surface-container: '#f0eee8'
  surface-container-high: '#ebe8e2'
  surface-container-highest: '#e5e2dc'
  on-surface: '#1c1c18'
  on-surface-variant: '#42493e'
  inverse-surface: '#31312d'
  inverse-on-surface: '#f3f0ea'
  outline: '#72796e'
  outline-variant: '#c2c9bb'
  surface-tint: '#3b6934'
  primary: '#154212'
  on-primary: '#ffffff'
  primary-container: '#2d5a27'
  on-primary-container: '#9dd090'
  inverse-primary: '#a1d494'
  secondary: '#914c00'
  on-secondary: '#ffffff'
  secondary-container: '#ff9f4e'
  on-secondary-container: '#6f3900'
  tertiary: '#003c5c'
  on-tertiary: '#ffffff'
  tertiary-container: '#195479'
  on-tertiary-container: '#95c8f2'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bcf0ae'
  primary-fixed-dim: '#a1d494'
  on-primary-fixed: '#002201'
  on-primary-fixed-variant: '#23501e'
  secondary-fixed: '#ffdcc4'
  secondary-fixed-dim: '#ffb77f'
  on-secondary-fixed: '#2f1500'
  on-secondary-fixed-variant: '#6f3900'
  tertiary-fixed: '#cbe6ff'
  tertiary-fixed-dim: '#99ccf7'
  on-tertiary-fixed: '#001e30'
  on-tertiary-fixed-variant: '#084b6f'
  background: '#fcf9f3'
  on-background: '#1c1c18'
  surface-variant: '#e5e2dc'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  card-padding: 24px
  gutter: 16px
  section-gap: 32px
  safe-margin: 20px
---

## Brand & Style
The brand personality is **nurturing, curious, and vibrant**. Designed primarily for children and educators, this design system bridges the gap between playful discovery and structured learning. The emotional response is one of warmth and safety—an invitation to explore the natural world through a friendly, tactile lens.

The visual style is a blend of **Modern Minimalism and Tactile Illustration**. It avoids the clutter of traditional "kids" media, opting instead for clean layouts, generous whitespace (or color-blocks), and sophisticated character illustrations that feel like high-quality children’s literature. The focus is on clarity and the celebration of organic forms.

## Colors
The palette is rooted in a **warm, organic Earth-tone spectrum**. 
- **Deep Forest Green (Primary):** Used for primary headings and structural anchors, conveying growth and the natural world.
- **Earthy Orange (Secondary):** A vibrant sun-kissed accent used for callouts, highlights, and interactive elements.
- **Soft Sky Blue (Tertiary):** Used for background tints and secondary information containers to provide a breath of air.
- **Paper White (Neutral):** A slightly warm, off-white base that reduces eye strain and reinforces the tactile, "printed card" feel.
- **Bark Brown:** Reserved for body text and subtle borders to maintain a softer look than pure black.

## Typography
The typography is selected for high legibility and a friendly, contemporary character. 
- **Headlines:** Use **Plus Jakarta Sans** for its soft, rounded terminals and optimistic feel. It provides a strong visual anchor for animal names and card titles.
- **Body:** **Be Vietnam Pro** is utilized for its clean, open apertures, making it ideal for educational descriptions and facts.
- **Metadata/Technical:** **Space Grotesk** is used for classification labels (e.g., "MAMMAL", "HABITAT") to add a touch of modern, technical precision that contrasts with the organic illustrations.

## Layout & Spacing
The layout follows a **Fixed Grid** model optimized for the physical proportions of an educational flashcard. 
- **The Card Grid:** Elements are aligned to an 8px baseline rhythm. 
- **Hierarchy:** The top 60% of the card is dedicated to the visual (Illustration/Image), while the bottom 40% is reserved for educational copy and data.
- **Desktop/Tablet:** Content is displayed in a masonry or grid gallery.
- **Mobile:** Single-focus card view with vertical scrolling for detailed facts.
- **Margins:** A consistent "Safe Zone" of 20px is maintained around all edges to ensure readability and print compatibility.

## Elevation & Depth
In alignment with the "card" metaphor, depth is achieved through **Tonal Layering** rather than heavy shadows.
- **Level 0 (Background):** Neutral Paper White.
- **Level 1 (Card Surface):** High-contrast color blocks (Green/Orange) or white surfaces with a subtle, low-opacity 1px Bark Brown border.
- **Level 2 (Pop-outs/Modals):** Soft, tinted ambient shadows (using the Primary color at 5% opacity) to suggest the card is lifting off the table.
- **Glassmorphism:** Used sparingly for "Information Overlays" on top of animal illustrations, featuring a light background blur (8px) and a semi-transparent white tint.

## Shapes
The design system employs **Rounded** geometry to mirror the organic forms found in nature.
- **Standard Radius:** 0.5rem (8px) for small buttons and input fields.
- **Large Radius (Cards):** 1.5rem (24px) for the main card container to create a soft, kid-friendly silhouette.
- **Iconography:** Use thick, rounded strokes (2px minimum) to maintain visual consistency with the typography.

## Components
- **Educational Cards:** The hero component. Features a large illustration area, a "Headline-LG" title, and a "Label-Caps" category tag.
- **Action Buttons:** Large, pill-shaped buttons using the Secondary Orange. Text is "Label-Caps" for high visibility.
- **Fact Chips:** Small, rounded-xl containers with Tertiary Blue backgrounds used to list animal traits (e.g., "Herbivore", "Diurnal").
- **Classification Lists:** Clean, left-aligned lists using "Body-MD" with custom organic bullet points (dots or leaf shapes).
- **QR Code Container:** A white, rounded-lg frame with a 1px border, ensuring the scan area is distinct from the colorful background.
- **Illustration Style:** Modern, flat vector illustrations with textured brushes. Animals should have expressive, friendly eyes and simplified geometric shapes.