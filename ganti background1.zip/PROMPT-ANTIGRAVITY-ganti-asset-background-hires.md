# PROMPT ANTIGRAVITY — Ganti Asset Background Kartu dengan Versi Resolusi Tinggi

## Konteks

Root cause kualitas pecah/ngeblok di kartu cetak sudah dikonfirmasi:
**file asset background asli memang resolusinya rendah** (848x1264px),
kurang untuk cetak tajam di ukuran A6 300dpi (butuh minimal
~1240x1748px). Saya sudah siapkan versi baru hasil upscale AI
(ESPCN super-resolution 4x + sharpening) dengan resolusi **1500x2235px**
— cukup di atas kebutuhan minimum cetak A6, tapi tidak berlebihan
supaya file tidak terlalu berat.

File baru yang sudah saya siapkan (lampirkan ke Antigravity):
- `kartu-background-jungle-A6-1500x2235.jpg` (~587KB, **pakai ini**
  untuk dipakai di project — ringan tapi kualitas masih bagus)
- `kartu-background-jungle-A6-1500x2235.png` (~3.8MB, cadangan kalau
  butuh kualitas lossless maksimal, tapi lebih berat)

## ATURAN WAJIB

1. **Scope HANYA ganti file asset**, jangan ubah lagi layout/CSS/font
   kartu (sudah final dari task-task sebelumnya), jangan ubah lagi
   setup ukuran cetak A6 (sudah final), jangan sentuh logic QR/publish.
2. **Temukan SEMUA tempat asset lama ini dirujuk** — jangan cuma ganti
   di satu file. Cek kemungkinan dipakai di lebih dari satu tempat:
   halaman cetak kartu, preview kartu sebelum print (kalau ada tampilan
   preview di web sebelum tombol print ditekan), atau folder assets
   umum yang dipakai ulang di tempat lain. Laporkan semua lokasi yang
   ditemukan sebelum mengganti.
3. **Jangan cuma timpa nama file yang sama** tanpa cek dulu — pastikan
   referensi path/nama file di kode tetap konsisten setelah file
   diganti (kalau nama file baru beda, update juga semua referensi
   path-nya, jangan cuma copy-paste isi file lama dengan nama baru
   tanpa update kode).

## Scope Kerja

1. Salin file `kartu-background-jungle-A6-1500x2235.jpg` yang saya
   lampirkan ke folder asset project (folder yang sama tempat file
   background lama berada).
2. Ganti referensi path di kode (CSS/HTML/template kartu cetak) supaya
   menunjuk ke file baru ini, menggantikan file lama yang resolusinya
   rendah.
3. **Hapus atau arsipkan file lama** yang resolusinya rendah (848x1264)
   supaya tidak ada yang salah pakai file lama secara tidak sengaja di
   masa depan — tapi JANGAN hapus kalau ternyata file yang sama juga
   dipakai di tempat lain yang bukan kartu cetak ini (cek dulu sesuai
   poin Aturan Wajib #2).
4. Test ulang print preview (Ctrl+P) dengan setting kertas A6, zoom in
   ke bagian background untuk memastikan sudah tajam, tidak pecah/
   ngeblok lagi seperti sebelumnya.

## Yang TIDAK Boleh Berubah

- ❌ Layout/warna/font kartu.
- ❌ Setup ukuran cetak A6 (`@page`, dimensi fixed).
- ❌ Logic QR code / data dinamis (judul, tanggal, link).

## Bukti yang Harus Dilaporkan

1. Daftar semua file/lokasi kode yang direferensi ulang ke asset baru
   (poin Aturan Wajib #2).
2. Screenshot print preview (zoom in ke background) dengan file baru
   — dibandingkan dengan screenshot lama yang pecah, untuk perbandingan
   jelas.
3. Konfirmasi file asset lama beresolusi rendah sudah dihapus/diarsip
   (atau alasan kalau sengaja tidak dihapus).

Setelah selesai, tunjukkan hasilnya dan tunggu saya cek sebelum
dianggap final.
