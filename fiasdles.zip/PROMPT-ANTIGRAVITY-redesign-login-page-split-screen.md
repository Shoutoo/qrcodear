# PROMPT untuk Antigravity: Redesign Login Page (Final — Full-Screen Split Layout)

## Konteks

Ini REVISI dari prompt redesign login page sebelumnya. User sudah
kirim **mockup final** (bukan referensi Turki lagi) yang jadi acuan
visual pasti: layout split-screen 2 kolom, kiri panel ungu solid
(logo "Magic AR" + badge kuning "Edu" + badge kecil "Pembelajaran 3D &
AR Interaktif" + headline "Ubah Ekosistem & Model 3D Jadi Ajaib!" +
paragraf deskripsi + ilustrasi 3D di bawah), kanan panel putih (judul
"MASUK" + subteks + field "EMAIL AKUN" + field "KATA SANDI" dengan
ikon amplop/gembok di kiri field + ikon mata show/hide password +
tombol ungu solid full-width "MASUK SEKARANG" + link "Belum memiliki
akun? Daftar Akun Baru").

**Field login yang benar** (ganti dari prompt versi sebelumnya yang
masih terlalu umum): **Email Akun** + **Kata Sandi**, bukan
username/T.C Kimlik/dropdown apapun. Style field: border penuh tipis
rounded (bukan underline-only seperti draft sebelumnya) — ikuti persis
mockup, ada ikon di kiri tiap field, ikon show/hide password di kanan
field password.

## 3 Perbaikan yang WAJIB dari versi sebelumnya

### 1. Halaman harus FULL-SCREEN, bukan card mengambang sebagian

Implementasi sebelumnya bikin card login jadi kotak kecil di tengah
layar dengan banyak ruang kosong di sekitarnya. Ini SALAH. Yang benar:
**seluruh viewport (100vw x 100vh) terisi oleh 2 kolom ini** — kolom
kiri ungu dan kolom kanan putih sama-sama full-height dari atas
sampai bawah layar, tidak ada background lain yang kelihatan di
sekitarnya. Kalau perlu container terluar, container itu sendiri yang
full-screen, bukan card kecil di atas background lain.

### 2. Kolom kanan (putih) harus lebih rounded, jangan kaku

Sudut-sudut card/kolom kanan (terutama sudut kiri-atas & kiri-bawah
yang berbatasan dengan kolom ungu) harus pakai border-radius yang
cukup besar biar terlihat lembut menyatu, BUKAN siku 90 derajat kaku.
Ikuti proporsi rounded seperti di mockup (radius besar, bukan radius
kecil ala button biasa).

### 3. Ilustrasi kiri-bawah pakai file yang sudah disediakan (SUDAH transparan)

User sudah generate ilustrasinya sendiri (fox/rubah 3D muncul dari HP
dengan tema "AR Learning: Jungle Friends", ada tanaman pot, kartu QR
"Scan for Adventure", bintang-bintang dekoratif) dan sudah
diproses jadi PNG transparan: **`ar-login-illustration-transparent.png`**
(sudah dilampirkan/disediakan terpisah dari prompt ini — taruh di
folder assets project, sama seperti folder assets background kartu
cetak). PAKAI FILE INI LANGSUNG, jangan generate ulang ilustrasi baru.

Catatan kualitas: background sudah ditransparankan otomatis, ada
sedikit sisa artefak halus di tepi kanan-bawah gambar (bekas alas
platform) dan teks "SCAN FOR ADVENTURE" agak terpotong tipis di
bagian bawahnya. Kalau pas dipasang di panel ungu artefak itu masih
kelihatan mengganggu, TIDAK PERLU coba fix sendiri pakai image
editing — cukup kecilkan sedikit ukuran gambar atau geser posisi
supaya bagian artefak itu lebih ke bawah/tersembunyi sebagian oleh
tepi panel, itu cukup.

## Ringkasan requirement lain (tetap berlaku dari prompt sebelumnya)

- Warna ikut CSS/design token project yang sudah ada (ungu utama +
  kuning/gold aksen untuk badge "Edu"), jangan bikin palet baru.
- Field login pakai logic auth yang SUDAH JALAN dari FASE R5 (email +
  password, JWT) — murni redesign visual, jangan ubah logic.
- Teks headline & deskripsi kolom kiri: pakai draft dari mockup
  ("Ubah Ekosistem & Model 3D Jadi Ajaib!" + deskripsi platform AR
  untuk rantai makanan/studio 3D/kuis) sebagai acuan, boleh disesuaikan
  kecil kalau ada perbedaan istilah dengan branding project saat ini.
- Halaman ini jadi halaman PERTAMA dibuka saat website diakses (belum
  login), redirect ke dashboard Guru/Siswa sesuai role setelah login
  sukses — alur ini JANGAN diubah.
- Harus tetap responsive di mobile (kalau di layar sempit, kemungkinan
  kolom kiri ungu disembunyikan atau ditumpuk di atas, ikuti pola
  responsive yang sudah dipakai di komponen lain seperti navbar).

## Setelah selesai

Screenshot hasil akhir (desktop full-screen + mobile), pastikan tidak
ada ruang kosong/background lain yang kelihatan di luar 2 kolom ini,
dan sudut kolom kanan sudah rounded sesuai mockup.
